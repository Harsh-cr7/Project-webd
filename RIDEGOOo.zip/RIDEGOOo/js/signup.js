function sclick() {
    window.alert("REgistered!!!!!");
}