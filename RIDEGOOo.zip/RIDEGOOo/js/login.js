var sub = document.getElementById("sub");
var name = document.getElementById("usr");

function sclick() {
    window.alert('Successfully logged in! ');
}